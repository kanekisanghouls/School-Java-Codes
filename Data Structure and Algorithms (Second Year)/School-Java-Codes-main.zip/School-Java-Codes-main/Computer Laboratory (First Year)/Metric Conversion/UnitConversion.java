public class UnitConversion {
    
    public int PoundToOunce(int pound) {
        return pound * 16;
    }
    
    public int GramToMilligram(int gram) {
        return gram * 1000;
    }
    
    public int KilogramToCarat(int kilogram) {
        return kilogram * 5000;
    }
}