public class MetricConversion {
    
    public double MeterToCentimeter(int meter) {
        return meter * 100;
    }
    
    public int FeetToInch(int feet) {
        return feet * 12;
    }
    
    public double MileToKilometer(double mile) {
        return mile * 1.61;
    }
}