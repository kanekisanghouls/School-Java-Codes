import java.util.Scanner;
 public class Introduction{
    public static void main(String[] args){
      Scanner sc = new Scanner(System.in);
      System.out.print("My short introduction:\n");
      Introduction();
      System.out.print("\nSocial Media:\n");
      Links();
      System.out.print("\nIf you want to reach me here!\n");
      Facebook();
    
    }
    public static void Introduction(){
      System.out.println("Hello everyone!");
      System.out.println("");
      System.out.println("");
      System.out.println("");
    }
    public static void Links(){
      System.out.println("");
      System.out.println("");
      System.out.println(""); 
    }
    public static void Text(){
      System.out.println("");  
    }
 }

// * It depends on you. Make your own Introduction about yourself.
